How to obtain UMK3 ULTIMATE CUP EDITION rom.

You already must have UMK3 Juggernauts Hack rom. Unpack it, run flips.exe, and apply every patch to corresponding bin file. Rename new bin files equal as old. Pack new bin files back to archive with overwritting. You can replace with this rom any UMK3 hack or vanilla 1.2 version if you rename whole archive with same name. Delete nvram folder - it can contains old settings.
