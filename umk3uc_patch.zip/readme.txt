How to obtain UMK3 ULTIMATE CUP EDITION rom.

You shall have UMK3 Juggernauts Hack rom. Unpack it, run flips.exe, and apply every patch to corresponding bin file. Rename new bin files equal as old.

For using rom with MAME, pack new bin files back to archive with overwritting. You can replace with this rom any UMK3 hack or vanilla 1.2 version if you rename whole archive with same name. Delete nvram folder - it can contains old settings.

For using rom with hardware you should clean nvram and enable hardware compatibility in test menu.
