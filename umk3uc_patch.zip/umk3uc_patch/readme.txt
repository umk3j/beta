How to obtain UMK3 ULTIMATE CUP EDITION [181023] rom.
You should have either vanilla UMK3 rom for MAME emulator or UMK3 Juggernauts Hack rom. Unpack all bin files into current dir and run "Patch ROM.bat" utility. 
If you want to use it with regular MAME then rename file from "umk3uc.zip" to "umk3.zip" and replace rom into your emulator. You can use network MAME version as well where rom will be recognized. Download MAME distribution here: https://goo.gl/bXnqte This one can recognize UMK3 UC [180130]. You should patch it for the latest rom. Put only executable in the current dir and run "Patch MAME.bat". Return executable back.
Delete the "nvram" folder inside MAME directory after updating.
